<?php

namespace Tests\FFMpeg\Unit\Media;

use Tests\FFMpeg\Unit\TestCase;

abstract class AbstractMediaTestCase extends TestCase
{
}
