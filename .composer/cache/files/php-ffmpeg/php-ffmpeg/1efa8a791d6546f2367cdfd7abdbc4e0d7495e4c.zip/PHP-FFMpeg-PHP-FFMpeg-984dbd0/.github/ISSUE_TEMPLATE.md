| Q              | A
| -------------- | ---
| Bug?           | no
| New Feature?   | no
| Version Used   | Specific tag or commit sha
| FFmpeg Version | FFmpeg or AVConv and version
| OS             | Your OS and version

#### Actual Behavior

How does PHP-FFMpeg behave at the moment?

#### Expected Behavior

What is the behavior you expect?

#### Steps to Reproduce

What are the steps to reproduce this bug? Please add code examples,
screenshots or links to GitHub repositories that reproduce the problem.

#### Possible Solutions

If you have already ideas how to solve the issue, add them here.
Otherwise remove this section.
