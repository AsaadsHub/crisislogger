<?php

$loader = require __DIR__.'/../vendor/autoload.php';
$loader->add('Alchemy\Tests', __DIR__);
